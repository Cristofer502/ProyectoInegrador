package com.railway.springboot.Railway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailwayApplicationTests {

	@Test
	void contextLoads() {
	}

}
